(function(){
	window.addEvent('load', function(){
		new WOW().init();
	});
})();
